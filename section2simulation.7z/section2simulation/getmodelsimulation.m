function [mfr, mxt4, mxt3, mxt2, er12] = getmodelsimulation( num, crosstalk2, ft, fr, A,...
                                                                                       noRS, noRTamp, noRTphs, snr,...
                                                                                       method, mycmd,...
                                                                                       sgm, wd, ori )
mfr = []; mxt4 = []; mxt3 = [];  mxt2 = [];
fprintf('repeating %d: , ',300);
for kk=1:300 %% --- repeating 300 times ---  
    
    fprintf( '%d , ',kk);
    
    if isfind(mycmd,'fig1') % the xt setting of the manuscript fig1
        xt2 = crosstalk2.*exp(1i*rdp([-pi,pi],[1,num]));
        xt3 = crosstalk2.*exp(1i*rdp([-pi,pi],[1,num])).*cal_idb(rdp([-10,0],[1,num]));
        xt4 = crosstalk2.*exp(1i*rdp([-pi,pi],[1,num])).*cal_idb(rdp([0,10],[1,num]));

    elseif isfind(mycmd,'fig2') % the xt setting of the manuscript fig2
        xt2 = crosstalk2*exp(1i*rdp([-pi,pi]));
        xt3 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([-5,5]));
        xt4 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([-5,5]));

    elseif isfind(mycmd,'fig3') % the xt setting of the manuscript fig3
        xt2 = crosstalk2*exp(1i*rdp([-pi,pi]));
        if isfind(mycmd,'highxt')
            xt3 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([10,15]));
            xt4 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([10,15]));            
        else
            xt3 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([-5,5]));
            xt4 = crosstalk2*exp(1i*rdp([-pi,pi]))*cal_idb(rdp([-5,5]));
        end

    else
        error('undefined testing model ... ...');
    end

    [c, x, u, v, w, z, Y] = cal_smturb2vec( ft, 0, xt2, fr, xt3, xt4, A);

    %% ------------------- simulation for solving -------------------

    % --- vegetation ---
    xpol1 = noRS.*exp(1i*rdp([-pi,pi],[1,length(noRS)]));
    xpol2 = noRS.*exp(1i*rdp([-pi,pi],[1,length(noRS)]));
    vv = noRTamp;
    g  = 1/3*noRTphs.*noRTamp;
    hhhh = 1; % veg hhhh=1
    [ RS11, RS12, ~, ~, RS22, ~, ~, ~, ~, ~ ] =...
        cal_addC4turb( c, x, u, v, w, z, hhhh,xpol1,xpol1,g,...
                                              1/3.*noRTamp,1/3.*noRTamp,xpol2,...
                                                  1/3.*noRTamp,xpol2,...
                                                   vv, Y );
    sgm0 = hhhh./snr.^2;
    speckle = specklenoise(eye(2,2),7*7);  % 49-looks for additive whiten-noise
    RS11 = RS11 + speckle(1,1)*sgm0; 
    RS12 = RS12 + speckle(1,2)*sgm0; 
    RS22 = RS22 + speckle(2,2)*sgm0;   

    % --- trc ---
    [ tr11, tr21 ] = cal_addS2turb( c, x, u, v, w, z, 1, 0, 0, 1, Y );

    % --- 45dcr ---
    [ d45r11, d45r21 ] = cal_addS2turb( c, x, u, v, w, z, 0, 1, 1, 0, Y );

    % --- 0dcr ---
    [ d0r11, d0r21 ] = cal_addS2turb( c, x, u, v, w, z, 1, 0, 0, -1, Y );

    % --- arc ---
    [ arc11, arc21 ] = cal_addS2turb( c, x, u, v, w, z, 1, 1, -1, -1, Y );    

    
    % --- arii vegetation ---
    if exist('sgm','var') & ~isempty(sgm)

        for mm=1:num  
            theta = deg2rad(rdp([-40 40])); 
            sg = sgm(mm);
            p = 2.0806*sg^6-6.3350*sg^5+6.3864*sg^4-0.4431*sg^3-3.9638*sg^2-0.0008*sg+2;
            q = 9.0166*sg^6-18.779*sg^5+4.9590*sg^4+14.5629*sg^3-10.8034*sg^2+0.1902*sg+1;
            volumeC3 =   [3 0 1;0 2 0;1 0 3]/8+...
                       p*[-2*cos(2*theta) sqrt(2)*sin(2*theta) 0; sqrt(2)*sin(2*theta) 0 sqrt(2)*sin(2*theta); 0 sqrt(2)*sin(2*theta) 2*cos(2*theta)]/8+...
                       q*[cos(4*theta) -sqrt(2)*sin(4*theta) -cos(4*theta); -sqrt(2)*sin(4*theta) -2*cos(4*theta) sqrt(2)*sin(4*theta); -cos(4*theta) sqrt(2)*sin(4*theta) cos(4*theta)]/8;
            mC3toC4 = [1 0 0 0;0 1/sqrt(2) 1/sqrt(2) 0;0 0 0 1];
            volumeC4{mm} = mC3toC4'*volumeC3*mC3toC4;
        end

        % C11/C22/C33/C44 may be negative when sg is smaller than 0 (it will be dropped in main function)
        [C11, C12, C13, C14, C22, C23, C24, C33, C34, C44] = cal_m2v(volumeC4); 

        % ---------- for testing ----------
        [O11, O12, ~, ~, O22, ~, ~, ~, ~, ~] = cal_addC4turb( c, x, u, v, w, z, C11, C12, C13, C14, C22, C23, C24, C33, C34, C44, Y );

        % ---------- truth: transmit error only ----------
        [c, x, u, v, w, z, Y] = cal_smturb2vec( ft, 0, xt2, 1, 0, 0, 1);
        [r11, r12, ~, ~, r22, ~, ~, ~, ~, ~] = cal_addC4turb( c, x, u, v, w, z, C11, C12, C13, C14, C22, C23, C24, C33, C34, C44, Y );
        [realh, realalp] = Cloudeimage( r11, r12, r22 );

    elseif exist('wd','var') & ~isempty(wd)

        % --- xBragg  ---
        for mm=1:num  
            theta = rdp([-40 40]);                    % bragg-surface orientation
            inc = rdp([25 65]);                     % incident angle
            perm = rdp([1,  50])+1i*rdp([0,  50]);  % permittivity
            xbraggC4{mm} = simxbragg( wd(mm), theta, inc, perm );             
        end
        [C11, C12, C13, C14, C22, C23, C24, C33, C34, C44] = cal_m2v(xbraggC4);

        % ---------- for testing ----------
        [O11, O12, ~, ~, O22, ~, ~, ~, ~, ~] = cal_addC4turb( c, x, u, v, w, z, C11, C12, C13, C14, C22, C23, C24, C33, C34, C44, Y );

        % ---------- truth: transmit error only ----------
        [c, x, u, v, w, z, Y] = cal_smturb2vec( ft, 0, xt2, 1, 0, 0, 1);
        [r11, r12, ~, ~, r22, ~, ~, ~, ~, ~] = cal_addC4turb( c, x, u, v, w, z, C11, C12, C13, C14, C22, C23, C24, C33, C34, C44, Y );
        [realh, realalp] = Cloudeimage( r11, r12, r22 );

    elseif exist('ori','var') & ~isempty(ori)

        if isfind(mycmd,'dr')

            % --- measurments: dr with rotation ---
            hh = cosd(2*ori); vh = sind(2*ori); hv =sind(2*ori); vv = -cosd(2*ori);

        elseif isfind(mycmd,'dipole')

            % --- measurments: dipole ---
            hh = cosd(ori).^2; vh = sind(ori).*cosd(ori); hv = sind(ori).*cosd(ori); vv = sind(ori).^2;

        elseif isfind(mycmd,'arc')

            % --- measurments: arc ---
            hh = sind(ori).*cosd(ori); vh = cosd(ori).^2; hv = -sind(ori).^2; vv = -sind(ori).*cosd(ori);

        end

        % ---------- for testing ----------
        [ dp11, dp21 ] = cal_addS2turb( c, x, u, v, w, z, hh, vh, hv, vv, Y );

        % ---------- truth: transmit error only ----------
        [c, x, u, v, w, z, Y] = cal_smturb2vec( ft, 0, xt2, 1, 0, 0, 1);
        [ r11, r21 ]   = cal_addS2turb( c, x, u, v, w, z, hh, vh, hv, vv, Y ); clear c x u v w z;    
        real12 = r11./r21;

    end

    %% ------------------- solving -------------------
    if strcmp(method,'Lavalle')
        % --- estimation by full-model (3 crosstalks): Lavalle ---
        [mfr(kk,:), mxt4(kk,:), mxt3(kk,:), mxt2(kk,:)] = cal_sim3xt_estLavalle(d45r11, d45r21, tr11, tr21, RS11, RS12, RS22);

    elseif strcmp(method,'ATDV')
         % --- estimation by full-model (3 crosstalks): ARC+TCR+DCR+Veg
        [mfr(kk,:), mxt4(kk,:), mxt3(kk,:), mxt2(kk,:)] = cal_sim3xt_estARC_TCR_DCR_RS( arc21./arc11, tr21./tr11, d0r21./d0r11, RS11, RS12, RS22);

    elseif strcmp(method,'AT')
        % --- estimation by simplified model (1 crosstalk): ARC+TCR
        [mfr(kk,:), mxt4(kk,:)] = cal_sim1xt_estARC_TCR( arc21./arc11, tr21./tr11 );
        mxt3(kk,:) = 0; mxt2(kk,:) = 0;

    elseif strcmp(method,'AV')
        % --- estimation by simplified model (1 crosstalk): ARC+Veg
        [mfr(kk,:), mxt4(kk,:)] = cal_sim1xt_estARC_RS(1, 1, 1, abs(arc11).^2, arc11.*conj(arc21), abs(arc21).^2, RS11, RS12, RS22);
        mxt3(kk,:) = 0; mxt2(kk,:) = 0;

    elseif strcmp(method,'XT0')
        % --- estimation by simplified model (0 crosstalk): ARC
        [mfr(kk,:)] = cal_sim3xt_setingxt0( arc21./arc11 );
        mxt4(kk,:) = 0; mxt3(kk,:) = 0; mxt2(kk,:) = 0;

    end

    % ------------------- calibration error -------------------
    if ( exist('sgm','var') & ~isempty(sgm) ) | ( exist('wd','var') & ~isempty(wd) )
        [C11,C12,C22] = cal_rmvC2turb( mfr(kk,:), mxt3(kk,:), mxt4(kk,:), O11, O12, O22, Y );
        [h, alp] = Cloudeimage( C11, C12, C22 );
        er12(kk,:) = (realh./h).*exp(1i*deg2rad(realalp-alp));
    
    elseif exist('ori','var') & ~isempty(ori)
        [~,~,er12(kk,:)] = cal_rmvSppturb( mfr(kk,:), mxt3(kk,:), mxt4(kk,:), dp11, dp21, Y ); 
        er12(kk,:) = real12./er12(kk,:);

    end

end
fprintf('\n');
end
