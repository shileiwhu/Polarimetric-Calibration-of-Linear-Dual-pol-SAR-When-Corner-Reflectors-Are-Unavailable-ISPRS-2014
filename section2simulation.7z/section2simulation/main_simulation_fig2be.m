
close all
clear all
clc

%% This codes link to the ISPRS manuscript:
%% "Polarimetric Calibration of Linear Dual-pol SAR When Corner Reflectors Are Unavailable"
%% As the source code of Section 2, it validates the model simplification is robust to 
%% resist the error from the nature media in dual-pol SAR calibration

%% --- simulation on the manuscript figure 2 b/e plot (xbragg scattering at varying randomness) ---
num = 22;                                               % -- bin numbers
crosstalk2 = cal_idb(-35);                              % -- crosstalk level
ft = 1; fr = 1; A = cal_idb(0.5)*exp(1i*deg2rad(20));   % -- transmit imbalance fr/ receive imbalance fr/total gain A
noRS = cal_idb(-30);                                    % -- no-reflection symmetry error: -30 dB
noRTamp = cal_idb(3);                                   % -- no-rotation symmetry error amp=3dB
noRTphs = exp(1i*deg2rad(120));                         % -- no-rotation symmetry error phs=120
snr     = cal_idb(30);                                  % -- snr=hhhh/NESZ: 30 dB

%% full model (3crosstalk) solved by Lavalle method
wda = linspace(-0.1, 0.6,num);
[~, ~, ~, ~, er12Lava] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'Lavalle', 'fig2', [], wda );

%% full model (3crosstalk) solved by Active reflector + ...
%% Trihedral corner reflector + Dihedral corner reflector + Vegetation (ATDV) method
wdb = wda - 0.050;
[~, ~, ~, ~, er12ATDV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'ATDV', 'fig2', [], wdb );

%% simplified model (1crosstalk) solved by Active reflector + trihedral corner reflector (AT)
wdc = wda - 0.025;
[~, ~, ~, ~, er12AT] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AT', 'fig2', [], wdc );

%% simplified model (1crosstalk) solved by Active reflector + Vegetation (AV)
wdd = wda + 0.025;
[~, ~, ~, ~, er12AV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AV', 'fig2', [], wdd );

%% simplified model (0crosstalk) solved by Active reflector (XT0)
wde = wda + 0.050;
[~, ~, ~, ~, er12XT0] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'XT0', 'fig2', [], wde );
    
%% ----------------------- imbalance amplitude ------------------
figure,hold on;
subplot(1,2,1), hold on, errorbar( wda, mean(cal_db(er12Lava),1), std(cal_db(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,1), hold on, errorbar( wdb, mean(cal_db(er12ATDV),1), std(cal_db(er12ATDV),[],1), 'r-');
subplot(1,2,1), hold on, errorbar( wdc, mean(cal_db(er12AT),1), std(cal_db(er12AT),[],1), 'b-');
subplot(1,2,1), hold on, errorbar( wdd, mean(cal_db(er12AV),1), std(cal_db(er12AV),[],1), 'g-');
subplot(1,2,1), hold on, errorbar( wde, mean(cal_db(er12XT0),1), std(cal_db(er12XT0),[],1), 'k-'); 
xlim([0.0,0.5]), ylim([-1.5,1.5]);
xlabel('Xbragg randomness (degree)'), ylabel('Htruth/Hestimation (dB)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

%% ----------------------- imbalance phase -----------------------
subplot(1,2,2), hold on, errorbar( wda, mean(cal_deg(er12Lava),1), std(cal_deg(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,2), hold on, errorbar( wdb, mean(cal_deg(er12ATDV),1), std(cal_deg(er12ATDV),[],1), 'r-');
subplot(1,2,2), hold on, errorbar( wdc, mean(cal_deg(er12AT),1), std(cal_deg(er12AT),[],1), 'b-');
subplot(1,2,2), hold on, errorbar( wdd, mean(cal_deg(er12AV),1), std(cal_deg(er12AV),[],1), 'g-');
subplot(1,2,2), hold on, errorbar( wde, mean(cal_deg(er12XT0),1), std(cal_deg(er12XT0),[],1), 'k-');
xlim([0.0,0.5]), ylim([-8,8]);
xlabel('Xbragg randomness (degree)'), ylabel('∠αtruth-∠αestimation (degree)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

