function [fr, xt4, xt3] = cal_sim2xt_estARC_TCR_RS(apc1121, tr1121, O11, O12, O22)

%%
xt4 = 1./tr1121;

%%
delta = ( O12-conj(xt4).*O11 )./O22;
xt3   = ( -apc1121.*xt4 + 1)./( apc1121./delta - 1 );

%%
fr    = -xt4 + (1+xt3)./apc1121;

end

