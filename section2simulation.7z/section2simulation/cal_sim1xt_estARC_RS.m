function [fr, xt] = cal_sim1xt_estARC_RS(HC11, HC12, HC22, O11, O12, O22, RS11, RS12, RS22)

%% --- validation check ---
fr = sqrt(O22./O11./(HC22./HC11)).*exp(1i*angle(HC12.*conj(O12)));

for kk=1:10

    %% --- crosstalk ---
    xt = cal_estRSqx(fr, RS11, RS12, RS22);
    
    %% --- removing fr and crosstalk --- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    [C11, C12, C22] = cal_rmvC2turb( 1, xt, xt./fr, O11, O12, O22 );
    
    %% --- the refinement fr --- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    fr = sqrt(HC11./HC22./(C11./C22)).*exp(1i*angle(HC12.*conj(C12)));
    
end

end



function [xt] = cal_estRSqx(fr, RS11, RS12, RS22)

%% --- crosstalk ---
for kk=1:size(RS11,1)
for mm=1:size(RS11,2)    
    Q = RS12(kk,mm)/RS11(kk,mm);
    A = (1+1/3*conj(fr(kk,mm)));
    B = 2/3*conj(fr(kk,mm));
    x0 = inv([real(A)+real(B), imag(A)-imag(B);...
          imag(A)+imag(B), -real(A)+real(B)]) * [real(Q); imag(Q)];
    xt(kk,mm) = x0(1)+1i*x0(2);
end
end

end