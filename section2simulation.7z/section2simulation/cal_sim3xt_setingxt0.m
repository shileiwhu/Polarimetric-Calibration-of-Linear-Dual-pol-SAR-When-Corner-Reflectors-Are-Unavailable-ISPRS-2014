function [fr] = cal_sim3xt_setingxt0(arc2111)

%%
fr = arc2111;

end

