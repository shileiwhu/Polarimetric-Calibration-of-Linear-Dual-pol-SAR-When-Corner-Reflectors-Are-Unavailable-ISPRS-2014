
close all
clear all
clc

%% This codes link to the ISPRS manuscript:
%% "Polarimetric Calibration of Linear Dual-pol SAR When Corner Reflectors Are Unavailable"
%% As the source code of Section 2, it validates the model simplification is robust to 
%% resist the error from the nature media in dual-pol SAR calibration

%% --- simulation on the manuscript figure 3 b/e plot (arc at varying orientation angle) ---
num = 35;                                               % -- bin numbers
crosstalk2 = cal_idb(-35);                              % -- crosstalk level
ft = 1; fr = 1; A = cal_idb(0.5)*exp(1i*deg2rad(20));   % -- transmit imbalance fr/ receive imbalance fr/total gain A
noRS = cal_idb(-30);                                    % -- no-reflection symmetry error: -30 dB
noRTamp = cal_idb(3);                                   % -- no-rotation symmetry error amp=3dB
noRTphs = exp(1i*deg2rad(120));                         % -- no-rotation symmetry error phs=120
snr     = cal_idb(30);                                  % -- snr=hhhh/NESZ: 30 dB

%% full model (3crosstalk) solved by Lavalle method
oria = linspace(-5, 95,num);
[~, ~, ~, ~, er12Lava] =...
    getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'Lavalle', 'fig3-arc', [], [], oria );

%% full model (3crosstalk) solved by Active reflector + ...
%% Trihedral corner reflector + Dihedral corner reflector + Vegetation (ATDV) method
orib = oria - 4;
[~, ~, ~, ~, er12ATDV] =...
    getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'ATDV', 'fig3-arc', [], [], orib );

%% simplified model (1crosstalk) solved by Active reflector + trihedral corner reflector (AT)
oric = oria - 2;
[~, ~, ~, ~, er12AT] =...
    getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AT', 'fig3-arc', [], [], oric );

%% simplified model (1crosstalk) solved by Active reflector + Vegetation (AV)
orid = oria + 2;
[~, ~, ~, ~, er12AV] =...
    getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AV', 'fig3-arc', [], [], orid );

%% simplified model (0crosstalk) solved by Active reflector (XT0)
orie = oria + 4;
[~, ~, ~, ~, er12XT0] =...
    getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'XT0', 'fig3-arc', [], [], orie );
    
%% ----------------------- imbalance amplitude ------------------
figure,hold on;
subplot(1,2,1), hold on, errorbar( oria, mean(cal_db(er12Lava),1), std(cal_db(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,1), hold on, errorbar( orib, mean(cal_db(er12ATDV),1), std(cal_db(er12ATDV),[],1), 'r-');
subplot(1,2,1), hold on, errorbar( oric, mean(cal_db(er12AT),1), std(cal_db(er12AT),[],1), 'b-');
subplot(1,2,1), hold on, errorbar( orid, mean(cal_db(er12AV),1), std(cal_db(er12AV),[],1), 'g-');
subplot(1,2,1), hold on, errorbar( orie, mean(cal_db(er12XT0),1), std(cal_db(er12XT0),[],1), 'k-'); 
xlim([0.0,90]), ylim([-10,10]);
xlabel('Orientation angle of arc (degree)'), ylabel('HH/VHtruth/HH/VHestimation (dB)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

%% ----------------------- imbalance phase -----------------------
subplot(1,2,2), hold on, errorbar( oria, mean(cal_deg(er12Lava),1), std(cal_deg(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,2), hold on, errorbar( orib, mean(cal_deg(er12ATDV),1), std(cal_deg(er12ATDV),[],1), 'r-');
subplot(1,2,2), hold on, errorbar( oric, mean(cal_deg(er12AT),1), std(cal_deg(er12AT),[],1), 'b-');
subplot(1,2,2), hold on, errorbar( orid, mean(cal_deg(er12AV),1), std(cal_deg(er12AV),[],1), 'g-');
subplot(1,2,2), hold on, errorbar( orie, mean(cal_deg(er12XT0),1), std(cal_deg(er12XT0),[],1), 'k-');
xlim([0.0,90]), ylim([-50,50]);
xlabel('Orientation angle of arc (degree)'), ylabel('∠HH/VHtruth-∠HH/VHestimation (degree)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

