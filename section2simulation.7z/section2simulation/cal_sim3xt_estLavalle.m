function [fr, xt4, xt3, xt2] = cal_sim3xt_estLavalle(dr11, dr21, tr11, tr21, O11, O12, O22)

%%
fr = dr21;
xt2 = conj( dr21.*conj(tr21).*O11 + dr11.*O22 - O12.*fr )./conj(2*O22);
xt4 = tr21 - fr.*xt2;
xt3 = dr11 - xt2;


end

