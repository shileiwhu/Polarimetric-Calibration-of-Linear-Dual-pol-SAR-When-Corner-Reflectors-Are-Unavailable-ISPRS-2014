
close all
clear all
clc

%% This codes link to the ISPRS manuscript:
%% "Polarimetric Calibration of Linear Dual-pol SAR When Corner Reflectors Are Unavailable"
%% As the source code of Section 2, it validates the model simplification is robust to 
%% resist the error from the nature media in dual-pol SAR calibration

%% --- simulation on the manuscript figure 1 a/b/c plot ---
num = 22;                       % -- bin numbers
ft = 1; fr = 1; A = 1;          % -- transmit imbalance fr/ receive imbalance fr/total gain A
noRS    = cal_idb(-3000);       % -- no-reflection symmetry error (-3000 dB is ignorable)
noRTamp = cal_idb(0);           % -- no-rotation symmetry error amp=1(0dB) is ignorable
noRTphs = exp(1i*deg2rad(0));   % -- no-rotation symmetry error phs=0      is ignorable
snr     = cal_idb(2000);        % -- snr=hhhh/NESZ: 2000 dB is ignorable

%% full model (3crosstalk) solved by Lavalle method
crosstalk2a = cal_idb(linspace(-53,-8,num));
[frLava, xt4Lava, xt3Lava, xt2Lava] =...
    getmodelsimulation( num, crosstalk2a, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'Lavalle', 'fig1' );

%% full model (3crosstalk) solved by Active reflector + ...
%% Trihedral corner reflector + Dihedral corner reflector + Vegetation (ATDV) method
crosstalk2b = crosstalk2a*cal_idb(-3); % a small offset for displaying
[frATDV, xt4ATDV, xt3ATDV, xt2ATDV] =...
    getmodelsimulation( num, crosstalk2b, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'ATDV', 'fig1' );

%% simplified model (1crosstalk) solved by Active reflector + trihedral corner reflector (AT)
crosstalk2c = crosstalk2a*cal_idb(-1.5); % a small offset for displaying
[frAT, xtAT] =...
    getmodelsimulation( num, crosstalk2c, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AT', 'fig1' );

%% simplified model (1crosstalk) solved by Active reflector + Vegetation (AV)
crosstalk2d = crosstalk2a*cal_idb(1.5); % a small offset for displaying
[frAV, xtAV] =...
    getmodelsimulation( num, crosstalk2d, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AV', 'fig1' );

%% simplified model (0crosstalk) solved by Active reflector (XT0)
crosstalk2e = crosstalk2a*cal_idb(3); % a small offset for displaying
[frXT0] = getmodelsimulation( num, crosstalk2e, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'XT0', 'fig1' );

% ----------------------- crosstalk -----------------------
figure, hold on;
errorbar( cal_db(crosstalk2a), mean(cal_db(xt2Lava),1), std(cal_db(xt2Lava),[],1), 'm-','color',[0.9290 0.6940 0.1250]);
errorbar( cal_db(crosstalk2a), mean(cal_db(xt3Lava),1), std(cal_db(xt3Lava),[],1), 'm--','color',[0.9290 0.6940 0.1250]);
errorbar( cal_db(crosstalk2a), mean(cal_db(xt4Lava),1), std(cal_db(xt4Lava),[],1), 'm-.','color',[0.9290 0.6940 0.1250]); 

errorbar( cal_db(crosstalk2b), mean(cal_db(xt2ATDV),1), std(cal_db(xt2ATDV),[],1), 'r-');
errorbar( cal_db(crosstalk2b), mean(cal_db(xt3ATDV),1), std(cal_db(xt3ATDV),[],1), 'r--');
errorbar( cal_db(crosstalk2b), mean(cal_db(xt4ATDV),1), std(cal_db(xt4ATDV),[],1), 'r-.'); 

errorbar( cal_db(crosstalk2c), mean(cal_db(xtAT),1),   std(cal_db(xtAT),[],1), 'b-');
errorbar( cal_db(crosstalk2d), mean(cal_db(xtAV),1),   std(cal_db(xtAV),[],1), 'g-'); grid on;

xlim([-50,-10]), ylim([-60,0]);
xlabel('real crosstalk2'), ylabel('Estimation crosstalk (dB)');
legend({'Lavalle-xt2','Lavalle-xt3','Lavalle-xt4',...
        'ATDV-xt2','ATDV-xt3','ATDV-xt4','AT','AV'});

% ----------------------- imbalance amplitude -----------------------
figure, hold on;
errorbar( cal_db(crosstalk2a), mean(cal_db(frLava),1), std(cal_db(frLava),[],1), 'm-','color',[0.9290 0.6940 0.1250]);
errorbar( cal_db(crosstalk2b), mean(cal_db(frATDV),1), std(cal_db(frATDV),[],1), 'r-');
errorbar( cal_db(crosstalk2c), mean(cal_db(frAT),1), std(cal_db(frAT),[],1), 'b-');
errorbar( cal_db(crosstalk2d), mean(cal_db(frAV),1), std(cal_db(frAV),[],1), 'g-');
errorbar( cal_db(crosstalk2e), mean(cal_db(frXT0),1), std(cal_db(frXT0),[],1), 'k-');  grid on;
xlim([-50,-10]), ylim([-5,5]);
xlabel('real crosstalk2'), ylabel('Estimation |fr| (dB)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

% ----------------------- imbalance phase -----------------------
figure,hold on;
errorbar( cal_db(crosstalk2a), mean(cal_deg(frLava),1), std(cal_deg(frLava),[],1), 'm-','color',[0.9290 0.6940 0.1250]);
errorbar( cal_db(crosstalk2b), mean(cal_deg(frATDV),1), std(cal_deg(frATDV),[],1), 'r-');
errorbar( cal_db(crosstalk2c), mean(cal_deg(frAT),1), std(cal_deg(frAT),[],1), 'b-');
errorbar( cal_db(crosstalk2d), mean(cal_deg(frAV),1), std(cal_deg(frAV),[],1), 'g-');
errorbar( cal_db(crosstalk2e), mean(cal_deg(frXT0),1), std(cal_deg(frXT0),[],1), 'k-');  grid on;
xlim([-50,-10]), ylim([-80,80]);
xlabel('real crosstalk2'), ylabel('Estimation ∠fr (degree)');
legend({'Lavalle','ATDV','AT','AV','XT0'});


