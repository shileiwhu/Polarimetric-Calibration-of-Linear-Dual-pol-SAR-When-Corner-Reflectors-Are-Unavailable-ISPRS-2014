
close all
clear all
clc

%% This codes link to the ISPRS manuscript:
%% "Polarimetric Calibration of Linear Dual-pol SAR When Corner Reflectors Are Unavailable"
%% As the source code of Section 2, it validates the model simplification is robust to 
%% resist the error from the nature media in dual-pol SAR calibration

%% --- simulation on the manuscript figure 2 a/d plot (volume scattering at varying randomness) ---
num = 22;                                               % -- bin numbers
crosstalk2 = cal_idb(-35);                              % -- crosstalk level
ft = 1; fr = 1; A = cal_idb(0.5)*exp(1i*deg2rad(20));   % -- transmit imbalance fr/ receive imbalance fr/total gain A
noRS = cal_idb(-30);                                    % -- no-reflection symmetry error: -30 dB
noRTamp = cal_idb(3);                                   % -- no-rotation symmetry error amp=3dB
noRTphs = exp(1i*deg2rad(120));                         % -- no-rotation symmetry error phs=120
snr     = cal_idb(30);                                  % -- snr=hhhh/NESZ: 30 dB

%% full model (3crosstalk) solved by Lavalle method
sgma = linspace(-0.1, 1.1,num);
[~, ~, ~, ~, er12Lava] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'Lavalle', 'fig2', sgma );

%% full model (3crosstalk) solved by Active reflector + ...
%% Trihedral corner reflector + Dihedral corner reflector + Vegetation (ATDV) method
sgmb = sgma - 0.050;
[~, ~, ~, ~, er12ATDV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'ATDV', 'fig2', sgma );

%% simplified model (1crosstalk) solved by Active reflector + trihedral corner reflector (AT)
sgmc = sgma - 0.025;
[~, ~, ~, ~, er12AT] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AT', 'fig2', sgma );

%% simplified model (1crosstalk) solved by Active reflector + Vegetation (AV)
sgmd = sgma + 0.025;
[~, ~, ~, ~, er12AV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'AV', 'fig2', sgma );

%% simplified model (0crosstalk) solved by Active reflector (XT0)
sgme = sgma + 0.050;
[~, ~, ~, ~, er12XT0] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snr, 'XT0', 'fig2', sgma );
    
%% ----------------------- imbalance amplitude ------------------
figure,hold on;
subplot(1,2,1), hold on, errorbar( sgma, mean(cal_db(er12Lava),1), std(cal_db(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,1), hold on, errorbar( sgmb, mean(cal_db(er12ATDV),1), std(cal_db(er12ATDV),[],1), 'r-');
subplot(1,2,1), hold on, errorbar( sgmc, mean(cal_db(er12AT),1), std(cal_db(er12AT),[],1), 'b-');
subplot(1,2,1), hold on, errorbar( sgmd, mean(cal_db(er12AV),1), std(cal_db(er12AV),[],1), 'g-');
subplot(1,2,1), hold on, errorbar( sgme, mean(cal_db(er12XT0),1), std(cal_db(er12XT0),[],1), 'k-'); 
xlim([0.1,0.9]), ylim([-2,2]);
xlabel('Volume randomness (degree)'), ylabel('Htruth/Hestimation (dB)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

%% ----------------------- imbalance phase -----------------------
subplot(1,2,2), hold on, errorbar( sgma, mean(cal_deg(er12Lava),1), std(cal_deg(er12Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
subplot(1,2,2), hold on, errorbar( sgmb, mean(cal_deg(er12ATDV),1), std(cal_deg(er12ATDV),[],1), 'r-');
subplot(1,2,2), hold on, errorbar( sgmc, mean(cal_deg(er12AT),1), std(cal_deg(er12AT),[],1), 'b-');
subplot(1,2,2), hold on, errorbar( sgmd, mean(cal_deg(er12AV),1), std(cal_deg(er12AV),[],1), 'g-');
subplot(1,2,2), hold on, errorbar( sgme, mean(cal_deg(er12XT0),1), std(cal_deg(er12XT0),[],1), 'k-');
xlim([0.1,0.9]), ylim([-5,5]);
xlabel('Volume randomness (degree)'), ylabel('∠αtruth-∠αestimation (degree)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

