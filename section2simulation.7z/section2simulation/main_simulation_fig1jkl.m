
close all
clear all
clc

%% This codes link to the ISPRS manuscript:
%% "Polarimetric Calibration of Linear Dual-pol SAR When Corner Reflectors Are Unavailable"
%% As the source code of Section 2, it validates the model simplification is robust to 
%% resist the error from the nature media in dual-pol SAR calibration

%% --- simulation on the manuscript figure 1 j/k/l plot ---
num = 14;                                               % -- bin numbers
crosstalk2 = cal_idb(-35);                              % -- crosstalk level
ft = 1; fr = 1; A = cal_idb(0.5)*exp(1i*deg2rad(20));   % -- transmit imbalance fr/ receive imbalance fr/total gain A
noRS = cal_idb(-30);                                    % -- no-reflection symmetry error: -30 dB
noRTamp = cal_idb(3);                                   % -- no-rotation symmetry error amp=3dB
noRTphs = exp(1i*deg2rad(120));                         % -- no-rotation symmetry error phs=120

%% full model (3crosstalk) solved by Lavalle method
snra = cal_idb(linspace(-2,22,num));
[frLava, xt4Lava, xt3Lava, xt2Lava] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snra, 'Lavalle', 'fig1' );

%% full model (3crosstalk) solved by Active reflector + ...
%% Trihedral corner reflector + Dihedral corner reflector + Vegetation (ATDV) method
snrb = snra*cal_idb(2);
[frATDV, xt4ATDV, xt3ATDV, xt2ATDV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snrb, 'ATDV', 'fig1' );

%% simplified model (1crosstalk) solved by Active reflector + trihedral corner reflector (AT)
snrc = snra*cal_idb(1);
[frMd2, xtMd2] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snrc, 'AT', 'fig1' );

%% simplified model (1crosstalk) solved by Active reflector + Vegetation (AV)
snrd = snra*cal_idb(-2);
[frAV, xtAV] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snrd, 'AV', 'fig1' );

%% simplified model (0crosstalk) solved by Active reflector (XT0)
snre = snra*cal_idb(-1);
[frXT0] = getmodelsimulation( num, crosstalk2, ft, fr, A, noRS, noRTamp, noRTphs, snre, 'XT0', 'fig1' );

% ----------------------- crosstalk -----------------------
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snra), mean(cal_db(xt2Lava),1), std(cal_db(xt2Lava),[],1), '-','color',[0.9290 0.6940 0.1250]);
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snra), mean(cal_db(xt3Lava),1), std(cal_db(xt3Lava),[],1), '--','color',[0.9290 0.6940 0.1250]);
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snra), mean(cal_db(xt4Lava),1), std(cal_db(xt4Lava),[],1), '-.','color',[0.9290 0.6940 0.1250]);

figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snrb), mean(cal_db(xt2ATDV),1), std(cal_db(xt2ATDV),[],1), 'r-');
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snrb), mean(cal_db(xt3ATDV),1), std(cal_db(xt3ATDV),[],1), 'r--');
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snrb), mean(cal_db(xt4ATDV),1), std(cal_db(xt4ATDV),[],1), 'r-.'); 

figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snrc), mean(cal_db(xtMd2),1),   std(cal_db(xtMd2),[],1), 'b-');
figure(1), subplot(1,3,1), hold on, errorbar( cal_db(snrd), mean(cal_db(xtAV),1),   std(cal_db(xtAV),[],1), 'g-'); grid on;

xlim([0,20]), ylim([-60,0]);
xlabel('SNR=|E(|hh|^2)/σN'), ylabel('Estimation crosstalk (dB)');
legend({'Lavalle-xt2','Lavalle-xt3','Lavalle-xt4',...
        'ATDV-xt2','ATDV-xt3','ATDV-xt4','AT','AV'});

% ----------------------- imbalance amplitude -----------------------
figure(1), subplot(1,3,2), hold on, errorbar( cal_db(snra), mean(cal_db(frLava),1), std(cal_db(frLava),[],1), '-','color',[0.9290 0.6940 0.1250]);
figure(1), subplot(1,3,2), hold on, errorbar( cal_db(snrb), mean(cal_db(frATDV),1), std(cal_db(frATDV),[],1), 'r-');
figure(1), subplot(1,3,2), hold on, errorbar( cal_db(snrc), mean(cal_db(frMd2),1), std(cal_db(frMd2),[],1), 'b-');
figure(1), subplot(1,3,2), hold on, errorbar( cal_db(snrd), mean(cal_db(frAV),1), std(cal_db(frAV),[],1), 'g-');
figure(1), subplot(1,3,2), hold on, errorbar( cal_db(snre), mean(cal_db(frXT0),1), std(cal_db(frXT0),[],1), 'k-');  grid on;

xlim([0,20]), ylim([-2,2]);
xlabel('SNR=|E(|hh|^2)/σN'), ylabel('Estimation |fr| (dB)');
legend({'Lavalle','ATDV','AT','AV','XT0'});

% ----------------------- imbalance phase -----------------------
figure(1), subplot(1,3,3), hold on, errorbar( cal_db(snra), mean(cal_deg(frLava),1), std(cal_deg(frLava),[],1), '-','color',[0.9290 0.6940 0.1250]);
figure(1), subplot(1,3,3), hold on, errorbar( cal_db(snrb), mean(cal_deg(frATDV),1), std(cal_deg(frATDV),[],1), 'r-');
figure(1), subplot(1,3,3), hold on, errorbar( cal_db(snrc), mean(cal_deg(frMd2),1), std(cal_deg(frMd2),[],1), 'b-');
figure(1), subplot(1,3,3), hold on, errorbar( cal_db(snrd), mean(cal_deg(frAV),1), std(cal_deg(frAV),[],1), 'g-');
figure(1), subplot(1,3,3), hold on, errorbar( cal_db(snre), mean(cal_deg(frXT0),1), std(cal_deg(frXT0),[],1), 'k-');  grid on;

xlim([0,20]), ylim([-25,25]);
xlabel('SNR=|E(|hh|^2)/σN'), ylabel('Estimation ∠fr (degree)');
legend({'Lavalle','ATDV','AT','AV','XT0'});
