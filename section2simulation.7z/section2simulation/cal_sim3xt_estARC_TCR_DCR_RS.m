function [fr, xt4, xt3, xt2] = cal_sim3xt_estARC_TCR_DCR_RS(arc2111, tr2111, dr2111, RS11, RS12, RS22)
% --- tr2111 = vh/hh ---
% --- arc2111 = vh/hh ---
% --- dcr2111 = vh/vv ---
% --- TCR [1 0;0 1] ---
% --- ARC [1 -1;1 -1] ---
% --- DCR [1 0; 0 -1] ---

xt4 = ( tr2111 + dr2111 )/2;

A = ( tr2111 - dr2111 )/2;
B = arc2111;
C = ( xt4 - A )./B;
D = RS12./RS11 - conj(xt4) - conj(A)/3;

% --- searching best fr ---
f0 = cal_sim3xt_setingxt0(arc2111);
for kk=1:size(arc2111,1)
for mm=1:size(arc2111,2)
    amp = linspace( cal_db(f0(kk,mm))-0.5, cal_db(f0(kk,mm))+0.5, 100 );
    phs = linspace( cal_deg(f0(kk,mm))-20, cal_deg(f0(kk,mm))+20, 120 );
    [x,y] = meshgrid(amp,phs);
    f = cal_idb(x).*exp(1i*deg2rad(y));    
    nL = abs( 2*A(kk,mm)./f - 3*D(kk,mm)./conj(f) + f./B(kk,mm) - (1-C(kk,mm)) ).^2;
    [J,I] = find(nL==min(nL(:)),1,'first');
    fr(kk,mm) = cal_idb(amp(I))*exp(1i*deg2rad(phs(J)));
end
end

xt2 = A./fr;

xt3 = 3*D./conj(fr) - xt2;

end


