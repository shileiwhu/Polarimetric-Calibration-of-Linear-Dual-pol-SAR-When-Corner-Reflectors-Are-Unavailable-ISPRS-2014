function [fr, xt] = cal_sim1xt_estARC_TCR(arc2111, tr2111)
% --- tr2111 = vh/hh ---
% --- arc2111 = vh/hh ---
% --- TCR [1 0;0 1] ---
% --- ARC [1 -1;1 -1] ---

% a = 1;
% b = 1 - tr2111 - arc2111;
% c = tr2111 - arc2111;
% fr = (-b + sqrt(b.^2-4.*a.*c))./(2*a); % always close to arc2111 when setting tr2111=0
% xt = tr2111./(1+fr);

xt(1,:) = tr2111;
fr(1,:)  = arc2111;
for kk=2:10
    xt(kk,:) = tr2111./(1+fr(kk-1,:));
    fr(kk,:) = (arc2111-xt(kk,:))./(1-xt(kk,:));

end
fr = fr(end,:); xt = xt(end,:);

end

